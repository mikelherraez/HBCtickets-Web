const URL_BACK = "http://54.160.243.81:8080";

export default URL_BACK;
